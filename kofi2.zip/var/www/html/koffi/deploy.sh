#!/bin/bash

# Configuration - Edit these values
FTP_HOST="ftp.bakili.co.za"
FTP_USER="admin@bakili.co.za"
FTP_PASS="Support1@7509"
REMOTE_PATH="/home/bakilcml/kofi.bakili.co.za"

BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Starting Laravel deployment process...${NC}"

# Step 1: Build the project
echo -e "${YELLOW}📦 Running npm build...${NC}"
npm run build
if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Build failed! Aborting deployment.${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Build completed successfully${NC}"

# Step 2: Backup current .env file from server (preserve server config)
echo -e "${YELLOW}💾 Backing up server .env file...${NC}"
lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" << EOF
set ssl:verify-certificate no
set ftp:ssl-allow yes
set ftp:ssl-force yes
cd $REMOTE_PATH
mkdir -p backups
get .env backups/.env.server.backup || echo "No .env file found on server"
quit
EOF

# Step 3: Create backup of current deployment (excluding .env to avoid overwriting)
echo -e "${YELLOW}💾 Creating backup of current deployment...${NC}"
lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" << EOF
set ssl:verify-certificate no
set ftp:ssl-allow yes
set ftp:ssl-force yes
cd $REMOTE_PATH
mkdir -p backups/$BACKUP_DIR
mirror --reverse --delete --verbose --exclude-glob .env . backups/$BACKUP_DIR
quit
EOF

# Step 4: Sync files to server (excluding unnecessary files and .env)
echo -e "${YELLOW}🔄 Syncing files to server...${NC}"
lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" << EOF
set ssl:verify-certificate no
set ftp:ssl-allow yes
set ftp:ssl-force yes
set ftp:list-options -a
cd $REMOTE_PATH
mirror --reverse --delete --verbose \
    --exclude-glob node_modules/ \
    --exclude-glob .git/ \
    --exclude-glob .env.local \
    --exclude-glob .env \
    --exclude-glob storage/logs/ \
    --exclude-glob bootstrap/cache/ \
    --exclude-glob public/hot \
    --exclude-glob '*.log' \
    --exclude-glob deploy.sh \
    --exclude-glob backups/ \
    . .
quit
EOF

# Step 5: Restore the server's .env file if it was backed up
echo -e "${YELLOW}🔧 Restoring server .env file...${NC}"
lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" << EOF
cd $REMOTE_PATH
put backups/.env.server.backup .env || echo "No server .env backup to restore"
quit
EOF

# Step 6: Set proper permissions (if your host supports it)
echo -e "${YELLOW}🔒 Setting file permissions...${NC}"
lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" << EOF
cd $REMOTE_PATH
quote SITE CHMOD 755 .
quote SITE CHMOD 644 .env
quote SITE CHMOD -R 755 storage/
quote SITE CHMOD -R 755 bootstrap/cache/
quit
EOF

echo -e "${GREEN}🎉 Deployment completed successfully!${NC}"
echo -e "${BLUE}📁 Backup created at: backups/$BACKUP_DIR${NC}"
echo -e "${GREEN}✅ Server .env file preserved${NC}"

# Optional: Clear Laravel caches (if your host supports these commands)
echo -e "${YELLOW}🧹 Clearing Laravel caches...${NC}"
lftp -u "$FTP_USER","$FTP_PASS" "$FTP_HOST" << EOF
cd $REMOTE_PATH
quote SITE php artisan config:cache
quote SITE php artisan route:cache
quote SITE php artisan view:cache
quit
EOF

echo -e "${GREEN}🏁 All done! Your Laravel app has been deployed.${NC}"