
## SET UP

<p>rename .evn.example to .env</p>
<p>Run composer install</p>
<p>php artisan key:generate</p>
<p>Set up your database configuration</p>
<p>Run php artisan migrate</p>
<p>Run nvm run dev (ensure you using node version 20 or newer)</p>
<p>Run php artisan serve</p>
<p>Visit application at address. eg http//localhost:8000</p>


